package com.example.shubham_task;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class adapter_home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adapter_home);
    }
}