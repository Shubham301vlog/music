package com.example.shubham_task;

public class PojoItems {

    public String name;
    public String image_url;

    public PojoItems(String name, String image_url) {
        this.name = name;
        this.image_url = image_url;
    }
}
