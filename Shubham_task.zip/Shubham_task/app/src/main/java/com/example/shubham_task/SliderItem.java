package com.example.shubham_task;

public class SliderItem {


    public String imageUrl;

    public SliderItem(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
